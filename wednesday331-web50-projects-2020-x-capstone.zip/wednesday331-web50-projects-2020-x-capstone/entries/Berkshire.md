#Berkshire County  

**Federal Information Processing Standard (FIPS) Code:** 003  
**County Seat:** Pittsfield  
**Year Established:** 1761  
**Origin:** From part of Hampshire County. Government abolished in 2000.  
**Etymology:** For the English county of Berkshire  
**Population:** 124,944  
**Area:** 931 sq mi (2,411 sq km)  
**Map:**
