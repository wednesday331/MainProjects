#Essex County  

**Federal Information Processing Standard (FIPS) Code:** 009  
**County Seat:** Salem, Lawrence  
**Year Established:** 1643  
**Origin:** One of four original counties created in the Massachusetts Bay Colony. Government abolished in 1999.  
**Etymology:** For the English county of Essex  
**Population:** 789,034  
**Area:** 498 sq mi (1,290 sq km)  
**Map:**
