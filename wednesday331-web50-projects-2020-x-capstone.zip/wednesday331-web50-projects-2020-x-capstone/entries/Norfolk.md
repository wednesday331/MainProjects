#Norfolk County  

**Federal Information Processing Standard (FIPS) Code:** 021  
**County Seat:** Dedham  
**Year Established:** 1793  
**Origin:** From part of Suffolk County.  
**Etymology:** For the English county of Norfolk  
**Population:** 706,775  
**Area:** 400 sq mi (1,036 sq km)  
**Map:**
