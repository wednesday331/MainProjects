# Dukes County  

**Federal Information Processing Standard (FIPS) Code:** 007  
**County Seat:** Edgartown  
**Year Established:** 1695  
**Origin:** From Martha's Vineyard and the Elizabeth Islands, which had been part of Dukes County, New York until Massachusetts gained it in 1691  
**Etymology:** Formerly a part of Dukes County, New York until 1691, the land at one time was the possession of the dukes of York  
**Population:** 17,332  
**Area:** 104 sq mi (269 sq km)  
**Map:**
