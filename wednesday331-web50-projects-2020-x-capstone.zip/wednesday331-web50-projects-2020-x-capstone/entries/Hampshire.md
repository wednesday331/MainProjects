#Hampshire County  

**Federal Information Processing Standard (FIPS) Code:** 015  
**County Seat:** Northampton  
**Year Established:** 1662  
**Origin:** From unorganized territory in the western part of the Massachusetts Bay Colony. Government abolished 1999.  
**Etymology:** For the English county of Hampshire  
**Population:** 160,830  
**Area:** 529 sq mi (1,370 sq km)  
**Map:**
