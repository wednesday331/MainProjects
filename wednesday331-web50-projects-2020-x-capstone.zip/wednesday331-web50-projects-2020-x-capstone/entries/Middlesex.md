#Middlesex County  

**Federal Information Processing Standard (FIPS) Code:** 017  
**County Seat:** Lowell,Cambridge  
**Year Established:** 1643  
**Origin:** One of four original counties created in the Massachusetts Bay Colony. Government abolished in 1997.  
**Etymology:** For the English county of Middlesex  
**Population:** 1,611,699  
**Area:** 824 sq mi (2,134 sq km)  
**Map:**
