#Plymouth County  

**Federal Information Processing Standard (FIPS) Code:** 023  
**County Seat:** Brockton, Plymouth  
**Year Established:** 1685  
**Origin:** One of three original counties created in the Plymouth Colony.  
**Etymology:** For its seat of Plymouth, which is named for the English port city of Plymouth  
**Population:** 521,202  
**Area:** 661 sq mi (1,712 sq km)  
**Map:**
