#Hampden County  

**Federal Information Processing Standard (FIPS) Code:** 013  
**County Seat:** Springfield  
**Year Established:** 1812  
**Origin:** From part of Hampshire County. Government abolished in 1998.  
**Etymology:** John Hampden (1595—1643), the famous 17th century English parliamentarian  
**Population:** 466,372  
**Area:** 618 sq mi (1,601 sq km)  
**Map:**
