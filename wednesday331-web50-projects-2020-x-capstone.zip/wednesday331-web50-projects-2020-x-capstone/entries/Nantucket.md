#Nantucket County  

**Federal Information Processing Standard (FIPS) Code:** 019  
**County Seat:** Nantucket  
**Year Established:** 1695  
**Origin:** From Nantucket Island which had been part of Dukes County, New York until Massachusetts gained it in 1691.  
**Etymology:** The Town of Nantucket, itself derived from a Wampanoag word meaning "place of peace"  
**Population:** 11,399  
**Area:** 48 sq mi (124 sq km)  
**Map:**
