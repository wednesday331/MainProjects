#Suffolk County  

**Federal Information Processing Standard (FIPS) Code:** 025  
**County Seat:** Boston  
**Year Established:** 1643  
**Origin:** One of four original counties created in the Massachusetts Bay Colony. Government abolished in 1999.  
**Etymology:** For the English county of Suffolk  
**Population:** 803,907  
**Area:** 58 sq mi (150 sq km)  
**Map:**
