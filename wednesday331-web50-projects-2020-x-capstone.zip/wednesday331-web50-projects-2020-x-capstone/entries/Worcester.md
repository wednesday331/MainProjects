#Worcester County  

**Federal Information Processing Standard (FIPS) Code:** 027  
**County Seat:** Worcester  
**Year Established:** 1731  
**Origin:** From parts of Hampshire County, Middlesex County and Suffolk County. Government abolished in 1998.  
**Etymology:** For its county seat of Worcester, which is named in honor of the English city of Worcester and the English Civil War Battle of Worcester in 1651, a Parliamentarian victory.  
**Population:** 830,622  
**Area:** 1,513 sq mi (3,919 sq km)  
**Map:**
