#Franklin  County  

**Federal Information Processing Standard (FIPS) Code:** 011  
**County Seat:** Greenfield  
**Year Established:** 1811  
**Origin:** From part of Hampshire County. Government abolished in 1997.  
**Etymology:** For Benjamin Franklin (1706–1790), early American scientist, diplomat, and politician  
**Population:** 70,180  
**Area:** 702 sq mi (1,818 sq km)  
**Map:**
