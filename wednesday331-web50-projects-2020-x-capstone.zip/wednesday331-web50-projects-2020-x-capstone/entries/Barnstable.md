#Barnstable County

**Federal Information Processing Standard (FIPS) Code:** 001
**County Seat:** Barnstable
**Year Established:** 1685
**Origin:** One of three original counties created in the Plymouth Colony
**Etymology:** After its county seat of Barnstable, which is named after the English town of Barnstaple.
**Population:** 212,990
**Area:** 396 sq mi(1,026 sq km)
**Map:**
